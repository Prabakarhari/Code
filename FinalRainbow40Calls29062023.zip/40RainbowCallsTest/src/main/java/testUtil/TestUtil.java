package testUtil;

import java.io.IOException;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import mevan.TestBase.BaseTest;

public class TestUtil extends BaseTest{
	
	public TestUtil() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static long PAGE_LOAD_TIMEOUT=500;
	public static long IMPLICIT_WAIT=500;
	
	public static int screenShotCount = 0;
	
	public static Logger LOGGER = Logger.getLogger("RAINBOWLog");  
	public static FileHandler filehandler; 
	public static Properties prop;
	public static int webRTCCheckCount = 0;
	public static int conversation_duration = 0;

	
}
