package mevan.RainbowCallsTest;

import org.testng.annotations.Test;

import java.awt.AWTException;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.BeforeClass;
import mevan.TestBase.BaseTest;
import testUtil.TestUtil;

public class FourthRainbowCallWithTabs extends BaseTest{

	private List<User> users;
	

	@BeforeClass
	public void initializationsetUp() throws InterruptedException {
		driver = BaseTest.getDriver();
		initialization(driver);
	}

	@Test
	public void testMultipleUserLogin() throws IOException, InterruptedException, AWTException, TimeoutException {
		users = readUsersFromExcel("RainbowCallFourthLoginData.xlsx");
		System.out.println("UserCount" + users.size());

		try {
			User firstUser = users.get(0);
			TestUtil.LOGGER.info("*******USER INFORMATION ************\r\n"
					+ ">>USER EMAIL_ID            : " + firstUser.getEmail() + "\r\n"
					+ ">>USER DIAL TO             : " + firstUser.getEdn() + "\r\n"
					+ "********USER INFORMATION ENDS*********\r\n\n");

			performLogin(firstUser.getEmail(), firstUser.getPassword());
			Thread.sleep(4000);
			closePopup();
			TelephonyStatus();
			dialPadClick();
			DialNumberTab(firstUser.getEdn());
			MakeCall();

			Thread.sleep(7000);
			ConversationActive();

			for (int i = 1; i < users.size(); i++) {
				User currentUser = users.get(i);

				try {
					openNewTab();
					switchToTab(i + 1);
					initialization(driver);
					logout();
					switchToTab(i + 1);

					TestUtil.LOGGER.info("*******USER INFORMATION ************\r\n"
							+ ">>USER EMAIL_ID            : " + currentUser.getEmail() + "\r\n"
							+ ">>USER DIAL TO             : " + currentUser.getEdn() + "\r\n"
							+ "********USER INFORMATION ENDS*********\r\n\n");

					performLogin(currentUser.getEmail(), currentUser.getPassword());
					Thread.sleep(4000);
					TelephonyStatus();
					dialPadClick();
					Thread.sleep(2000);
					DialNumberTab(currentUser.getEdn());
					MakeCall();
					System.out.println("Call initiated for user " + (i+1));
					Thread.sleep(7000);
					ConversationActive();


				} catch (Exception ex) {
					String errorMessage = ex.getMessage();
					System.out.println("Error occurred for user: " + currentUser.getEmail());
					System.out.println("Error message: " + errorMessage);
					captureScreenshot("error_screenshot.png");

				}
			}
		} catch (Exception ex) {
			String errorMessage = ex.getMessage();
			System.out.println("Error occurred for the first user");
			System.out.println("Error message: " + errorMessage);
			captureScreenshot("error_screenshot.png");

		}
	}

	private List<User> readUsersFromExcel(String filePath) throws IOException {
		List<User> users = new ArrayList<>();

		FileInputStream file = new FileInputStream(filePath);
		Workbook workbook = WorkbookFactory.create(file);
		Sheet sheet = workbook.getSheetAt(0);

		for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			Row row = sheet.getRow(i);

			Cell emailCell = row.getCell(0);
			Cell passwordCell = row.getCell(1);
			Cell ednCell = row.getCell(2);

			if (emailCell != null && passwordCell != null && ednCell != null) {
				String email = getStringCellValue(emailCell);
				String password = getStringCellValue(passwordCell);
				int edn = getNumericCellValue(ednCell);

				users.add(new User(email, password, edn));
			} else {
				System.out.println("Skipping invalid row: " + (i + 1));
			}
		}

		workbook.close();
		file.close();

		return users;
	}

	private String getStringCellValue(Cell cell) {
		if (cell.getCellType() == CellType.STRING) {
			return cell.getStringCellValue();
		} else {
			return String.valueOf(cell.getNumericCellValue());
		}
	}

	private int getNumericCellValue(Cell cell) {
		if (cell.getCellType() == CellType.NUMERIC) {
			return (int) cell.getNumericCellValue();
		} else if (cell.getCellType() == CellType.STRING) {
			try {
				return Integer.parseInt(cell.getStringCellValue());
			} catch (NumberFormatException e) {
				throw new IllegalStateException("Invalid EDN value: " + cell.getStringCellValue());
			}
		} else {
			throw new IllegalStateException("Invalid cell type for EDN");
		}
	}

	private void openNewTab() {
		((JavascriptExecutor) driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(tabs.size() - 1));
	}

	private void switchToTab(int tabIndex) {
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		int numTabs = tabs.size();

		if (numTabs > 0 && tabIndex >= 0 && tabIndex < numTabs) {
			String targetTab = tabs.get(tabIndex);
			driver.switchTo().window(targetTab);
		}
	}

	private class User {
		private String email;
		private String password;
		private int edn;

		public User(String email, String password, int edn) {
			this.email = email;
			this.password = password;
			this.edn = edn;
		}

		public String getEmail() {
			return email;
		}

		public String getPassword() {
			return password;
		}

		public int getEdn() {
			return edn;
		}
	}
}