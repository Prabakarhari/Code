package mevan.RainbowCallsTest;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;

import mevan.TestBase.BaseTest;


public class Runner {

	static TestNG testNG;

    public static void main(String[] args) {
        try {
            testNG = new TestNG();
            
            // Add the test classes to the testNG object
            List<Class<?>> testClasses = new ArrayList<>();
            testClasses.add(FirstRainbowCallWithTabs.class);
            testClasses.add(SecondRainbowCallWithTabs.class);
            
          /*  testClasses.add(ThirdRainbowCallWithTabs.class);
            testClasses.add(FourthRainbowCallWithTabs.class);
            testClasses.add(FifthRainbowCallWithTabs.class); */

            // Set the common setup and teardown class
            testNG.setTestClasses(new Class[] { BaseTest.class });

            // Set the test classes
            testNG.setTestClasses(testClasses.toArray(new Class[testClasses.size()]));

            // Run the testNG object
            testNG.run();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}