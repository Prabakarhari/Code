package mevan.TestBase;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import io.github.bonigarcia.wdm.WebDriverManager;
import testUtil.TestUtil;



public class BaseTest {
	
	    protected static WebDriver driver;
	    private static ChromeOptions options;
	    private static final String CONFIG_FILE_PATH = "config.properties";
	    protected long conversationDuration;
	    private static List<WebDriver> drivers = new ArrayList<>(); 
	    private int loginCount = 0;
	    private static int UserCallCount = 0;
	    private static int UserCount = 0;
	    private static int CONVERSATIONENDCOUNT=1;

	    public BaseTest() {
	        loadConfiguration();
	    }
	    
	    @BeforeSuite
	    public void setUp() throws InterruptedException {
	    	
	    	TestUtil.LOGGER.info("Rainbow Calls Test is started");
	        
	    }
	
	public static WebDriver getDriver() {
	
            // Initialize the driver and options here
            WebDriverManager.chromedriver().setup();
            
            options = new ChromeOptions();
            options.addArguments("--use-fake-ui-for-media-stream");
            options.addArguments("--no-sandbox");
            options.addArguments("--disable-dev-shm-usage");
            options.addArguments("--disable-extensions");
            options.addArguments("--disable-plugins");
            driver = new ChromeDriver(options); // Assign the driver object
            drivers.add(driver);
			return driver;
            
	}
	private void loadConfiguration() {
        
        try {
            FileInputStream ip = new FileInputStream(CONFIG_FILE_PATH);
            TestUtil.prop = new Properties();
            TestUtil.prop.load(ip);
             conversationDuration = Long.parseLong(TestUtil.prop.getProperty("conversation.duration")); 
             SimpleDateFormat dateandTime = new SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss_"); 
			 Date dateobj = new Date();
			 TestUtil.filehandler = new FileHandler(dateandTime.format(dateobj)+TestUtil.prop.getProperty("LOG_FILE_PATH"));  
			 TestUtil.LOGGER.addHandler(TestUtil.filehandler);
			 SimpleFormatter formatter = new SimpleFormatter();  
			 TestUtil.filehandler.setFormatter(formatter);  
        } catch (IOException e) {
            System.err.println("Failed to load configuration: " + e.getMessage());
            
            TestUtil.LOGGER.info("Exception occured in Failed to load configuration:"+ e.getMessage());
        }
    }


    public long getConversationDuration() {
        return conversationDuration;
    }


    @AfterSuite
    public void tearDown() throws InterruptedException {
        long conversationDuration = getConversationDuration();
        Thread.sleep(conversationDuration);

        // Release calls one by one
        for (WebDriver driver : drivers) {
        	// Get the window handles (tabs) for the current driver
            Set<String> windowHandles = driver.getWindowHandles();
            
            
            for (String windowHandle : windowHandles) {   
            driver.switchTo().window(windowHandle);
            TestUtil.LOGGER.info("Call HANG-UP initiated");
            JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
            
            // Execute JavaScript to click on the "end call" button
            jsExecutor.executeScript("document.getElementById('call-drop').click();");
            
            TestUtil.LOGGER.info("CONVERSATION COUNT <<< " + CONVERSATIONENDCOUNT + " >>> ---ENDED SUCCESSFULLY");

            Thread.sleep(1000); // Add a delay of 1 second between closing each tab
            CONVERSATIONENDCOUNT++;
            }  
        }

    }
	protected void initialization(WebDriver driver) throws InterruptedException {
		
		TestUtil.LOGGER.info("Rainbow initialization started"); 
		TestUtil.webRTCCheckCount = 0;
		// Navigate to the login page
		driver.get("https://web.openrainbow.net");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);	
		Thread.sleep(1000);

	}


	protected void waitForConversationCompletion( int conversationDurationInSeconds) {
		try {
			Thread.sleep(conversationDuration * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	protected void closePopup() throws TimeoutException, InterruptedException {
		WebDriverWait  wait = new WebDriverWait(driver, 10);
		WebElement popupElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(text(),' Close ')]")));

		// Close the popup if it is displayed
		if (popupElement.isDisplayed()) {
			WebElement closeButton = driver.findElement(By.xpath("//*[contains(text(),' Close ')]"));
			closeButton.click();
			Thread.sleep(3000);
			TestUtil.LOGGER.info("******** CLOSE POP UP IS CLOSED **********"); 
		}
		
		
	}
	


	protected  void performLogin(String username, String password) throws InterruptedException, AWTException {
		// Perform login using the provided username and password

		TestUtil.LOGGER.info("******** RAINBOW LOGIN STARTED **********"); 
		
		Thread.sleep(1000);

		WebElement usernameField = driver.findElement(By.xpath("//input[@name='username' and ancestor::form]"));
		//j.executeScript("arguments[0].click();", usernameField);
		usernameField.click();
		Thread.sleep(1000);
		usernameField.clear();
		usernameField.sendKeys(username);
		Thread.sleep(1000);
		WebDriverWait wait = new WebDriverWait(driver, 10);

		// Wait for the "Continue" button to be clickable or visible
		WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(text(),' Continue ')]")));

		if (continueButton.isEnabled()) {
			try {
				// Click the continue button using Actions class
				Actions actions = new Actions(driver);
				actions.moveToElement(continueButton).click().perform();
				System.out.println("Continue button clicked");
			} catch (Exception e) {
				System.out.println("Unable to click continue button: " + e.getMessage());
			}
		}


		Thread.sleep(1000);
		WebElement passwordInput = driver.findElement(By.xpath("//input[@name='authPwd' and ancestor::form]"));

		passwordInput.clear();
		passwordInput.sendKeys(password);
		Thread.sleep(1000);	
		driver.findElement(By.xpath("//*[contains(text(),' Connect ')]")).click();

		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
	
		System.out.println("SUCCESSFULLY LOGGED IN USER " + loginCount);
        TestUtil.LOGGER.info("SUCCESSFULLY LOGGED IN FOR USER <<< " + loginCount);
        loginCount++;
		

	}




	protected void dialPadClick() throws InterruptedException {
		
		TestUtil.LOGGER.info("*********** FOCUS ON DIAR-INPUT INITIATED **********");
		
		int waitTimeInSeconds = 15;
		try {
			
			WebDriverWait wait = new WebDriverWait(driver, waitTimeInSeconds);
	        WebElement dialpadIcon=  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class, 'c-button conversation-search-dialpadIcon') or contains(@class, 'c-icon--small')]")));
	        System.out.println("Dial Pad Icon Icon is active");
	        dialpadIcon.sendKeys(Keys.ENTER); 
	        Thread.sleep(1000);
		}catch (NoSuchElementException e) {
	        System.out.println("DialPad Icon Status is not Active");
	        TestUtil.LOGGER.info("******** EXCEPTION OCCURED IN DIALPAD **********");
	        Thread.sleep(1000);
	        
       }
		
	}
		

	protected  void DialNumberTab(int i) throws InterruptedException {


		String numberString = String.valueOf(i);
		String[] numbers = numberString.split("");

		for (String digit : numbers) {

			System.out.println(digit);
			if (digit.equals("1") || digit.equals("2") || digit.equals("3") || digit.equals("4") || digit.equals("5")
					|| digit.equals("6") || digit.equals("7") || digit.equals("8") || digit.equals("9")) {
				WebElement num = driver.findElement(By.xpath("(//div[@class='c-dialpad__key' and 'c-dialpad__keypad'])[" + digit + "]"));
				num.click();


			} else if (digit.equals("0")) {
				WebElement num = driver.findElement(By.xpath("(//div[@class='c-dialpad__key' and 'c-dialpad__keypad'])[11]"));
				num.click();

			}

			else if (digit.equals("*")) {
				WebElement num = driver.findElement(By.xpath("(//div[@class='c-dialpad__key' and 'c-dialpad__keypad'])[10]"));
				num.click();
			} else if (digit.equals("#")) {
				WebElement num = driver.findElement(By.xpath("(//div[@class='c-dialpad__key' and 'c-dialpad__keypad'])[12]"));
				num.click();
			}

		}
		}
	
	

	
	public  void MakeCall() throws InterruptedException
	{
		
		int waitTimeInSeconds = 20;
		
	
		
		try {
			
			WebDriverWait wait = new WebDriverWait(driver, waitTimeInSeconds);
	        WebElement MakeCallIcon=  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='c-icon c-icon--big' and ancestor::button]")));
	        System.out.println("MakeCall Icon is active");
	        MakeCallIcon.click();
	        Thread.sleep(1000);
	        System.out.println("Call initiated for user " + UserCount);
	        TestUtil.LOGGER.info("CALL INITIATED FOR USER <<< " + UserCount + " >>> --- SUCCESSFULLY");
	        UserCount++;

		}catch (NoSuchElementException e) {
	        System.out.println("MakeCall Icon Status is not Active");
	        TestUtil.LOGGER.info("******** EXCEPTION OCCURED IN MAKE CALL **********");
	        Thread.sleep(1000);
	       
       }
	

	}
	
	public static void captureScreenshot(String screenshotPath) {
		
		TestUtil.screenShotCount++;
		String randomScreenshotID = Integer.toString(TestUtil.screenShotCount);
		
		try {
		    File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		    String destinationFilePath = "screenshots/" + randomScreenshotID + "_" + screenshotPath;
		    File destinationFile = new File(destinationFilePath);
		    FileUtils.copyFile(screenshotFile, destinationFile);
		    System.out.println("Screenshot captured: " + destinationFile.getAbsolutePath());
		} catch (IOException e) {
		    System.out.println("Failed to capture screenshot: " + e.getMessage());
		    
		   
		}
	
	}
	protected static void ConversationActive() throws InterruptedException, TimeoutException {
		
		TestUtil.LOGGER.info("Focus On Conversation Active");
		int waitTimeInSeconds = 10;

		WebDriverWait wait = new WebDriverWait(driver, waitTimeInSeconds);
		WebElement statusElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='call-area-header_status']//span[2][@bold]")));
		String statusText = statusElement.getText();
		System.out.println(statusText);

		if (statusText.equalsIgnoreCase("Dialing") || statusText.equalsIgnoreCase("Ringing")) {
		    System.out.println("Conversation is dialing or ringing");
		    captureScreenshot("Conversation_Dialing_or_Ringing.png");
		    System.out.println("Waiting for Conversation Active status...");
		    TestUtil.LOGGER.info("Waiting for Conversation Active status...");
		    Thread.sleep(2000);
		    statusElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='call-area-header_status']//span[2][@bold]")));
		    statusText = statusElement.getText();
		    if (statusText.equalsIgnoreCase("Dialing") || statusText.equalsIgnoreCase("Ringing")) {
		        System.out.println("Conversation is still dialing or ringing after waiting");
		        TestUtil.LOGGER.info("******** CONVERSATION IS STILL DIALING OR RINGING AFTER WAITING **********");
		        captureScreenshot("Conversation_Status.png");
		    }
		}

		if (statusText.equalsIgnoreCase("Active")) {
			
		    System.out.println("*********** CONVERSATION IS ACTIVE AFTER WAITING **********");
		    TestUtil.LOGGER.info("******** CONVERSATION IS ACTIVE AFTER WAITING **********");
		    UserCallCount++;
		    System.out.println("Total Call Count: " + UserCallCount);
            TestUtil.LOGGER.info("CONVERSATION COUNT <<< " + UserCallCount + " >>> ---STARTED SUCCESSFULLY");
		} else {
		    System.out.println("Unknown conversation status: " + statusText);
		    captureScreenshot("Unknown_Status.png");
		}
	}	

	

	protected void TelephonyStatus() throws InterruptedException {
		TestUtil.LOGGER.info("Focus On Telephony Status");
		int waitTimeInSeconds = 15;

		try {
		    WebDriverWait wait = new WebDriverWait(driver, waitTimeInSeconds);
		    WebElement telephonyStatusIcon = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(@svgclass, 'c-icon c-icon--medium') and ancestor::telephonystatus]")));

		    String iconId = telephonyStatusIcon.getAttribute("iconid");
		    if (iconId != null && iconId.contains("help")) {
		        System.out.println("Telephony is help");
		        TestUtil.LOGGER.info("Telephony is help");
		    } else if (iconId != null && iconId.contains("telephony-off")) {
		        System.out.println("Telephony is Down");
		        // Handle telephony off state

		        System.out.println("Waiting for telephony status to be up...");
		        TestUtil.LOGGER.info("Waiting for telephony status to be up...");

		        // Wait for telephony to be up
		        Thread.sleep(3000);

		        // Check telephony status again
		        telephonyStatusIcon = driver.findElement(By.xpath("//*[contains(@svgclass, 'c-icon c-icon--medium') and ancestor::telephonystatus]"));
		        String iconId2 = telephonyStatusIcon.getAttribute("iconid");
		        if (iconId2 != null && (iconId2.contains("help") || iconId2.contains("telephony-off"))) {
		            System.out.println("Telephony is Off or help after waiting");
		            captureScreenshot( "Telephony_help or Off_after_waiting.png");
		            TestUtil.LOGGER.info("******** TELEPHONY IS OFF OR HEILP AFTER WAITING **********");
		        } else {
		            System.out.println("Telephony is up after waiting");
		            System.out.println("Select the Computer VOIP Option");
		            TestUtil.LOGGER.info("******** SELECTED THE CUMPUTOR VOIP OPTION **********");
		            
		            Thread.sleep(2000);
		            WebElement telephonyStatusElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(@class,'telephonyStatus')]")));
		            telephonyStatusElement.click();
		            System.out.println("Telephony Status is clicked");

		            Thread.sleep(3000);
		            WebElement computerOption = driver.findElement(By.xpath("//*[contains(text(), 'Computer (Internet calls)')]"));

		            if (computerOption.isDisplayed() && computerOption.isEnabled()) {
		                computerOption.click();
		                System.out.println("Telephony Status is Clicked");
		                System.out.println("Computer Telephony service is up");
		                TestUtil.LOGGER.info("******** COMPUTOR TELEPHONY SERVICE IS UP **********");
		            } else {
		                System.out.println("Computer Telephony service is greyed out");
		                TestUtil.LOGGER.info("******** COMPUTOR TELEPHONY SERVICE IS GREY OUT **********");
		                captureScreenshot("Computer_Telephony_service_grey_out.png");
		            }
		        }
		    } else {
		        System.out.println("Telephony is up");
		        System.out.println("Select the Computer VOIP Option");
		        TestUtil.LOGGER.info("******** SELECTED THE CUMPUTOR VOIP OPTION **********");
		        Thread.sleep(1000);
		        WebElement telephonyStatusElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(@class,'telephonyStatus')]")));
		        telephonyStatusElement.click();
		        System.out.println("Telephony Status is clicked");

		        Thread.sleep(2000);
		        WebElement computerOption = driver.findElement(By.xpath("//*[contains(text(), 'Computer (Internet calls)')]"));

		        if (computerOption.isDisplayed() && computerOption.isEnabled()) {
		            computerOption.click();
		            System.out.println("Telephony Status is Clicked");
		            System.out.println("Computer Telephony service is up");
		            TestUtil.LOGGER.info("******** COMPUTOR TELEPHONY SERVICE IS UP **********");
		        } else {
		            System.out.println("Computer Telephony service is greyed out");
		            TestUtil.LOGGER.info("******** COMPUTOR TELEPHONY SERVICE IS GREY OUT **********");
		            captureScreenshot("Computer_Telephony_service_grey_out.png");
		        }
		    }
		} catch (NoSuchElementException e) {
		    System.out.println("Telephony status icon not found");
		    TestUtil.LOGGER.info("Exception occured in Telephony status");
		    // Handle icon not found
		    captureScreenshot("Telephony_Status_Icon_Not_Found.png");
		} catch (InterruptedException e) {
		    // Handle InterruptedException
		}
	}

	protected void logout() throws InterruptedException {
		
		
	    TestUtil.LOGGER.info("Focus On logout Status");
	    try {
	    
	    int waitTimeInSeconds = 20;

	    WebDriverWait wait = new WebDriverWait(driver, waitTimeInSeconds);
	    WebElement telephonyStatusIcon= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(@svgclass, 'c-icon c-icon--medium') and ancestor::telephonystatus]")));
	    
	    String iconId = telephonyStatusIcon.getAttribute("iconid");
	    if (driver.findElements(By.xpath("//div[@class='call-area-header_status']/span[contains(text(), 'Active')]")).size() > 0
			    || ((iconId != null && (iconId.contains("help") || iconId.contains("telephony-off"))))) {
	    	
	    	
	    	    WebElement profile = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//user-avatar[@id='userAvatarMenu' and ancestor::user-menu]")));
	            profile.click();

	            WebElement logoutIcon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(text(), 'Log out') and ancestor::dropdown-item]")));
	            logoutIcon.click();

	            WebElement logoutButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@labelid='logout']")));
	            logoutButton.click();

	            System.out.println("Logout action is completed.");
	            TestUtil.LOGGER.info("******** LOGOUT ACTION IS COMPLETED **********");
	            
	            
	       
	    }
	    }catch (NoSuchElementException e) {
		    System.out.println("Logout action is not completed");
		    Thread.sleep(1000);
		    captureScreenshot("Logout_action_is_not_completed.png");
		    TestUtil.LOGGER.info(" Exception occured in Logout action"); 
		}
	
	    
}
	 
}		
		
		
		
	
		
